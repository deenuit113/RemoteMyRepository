#ifndef CTETRIS_H
#define CTETRIS_H
#include "Tetris.h"

class CTetris : public Tetris {
public:
    CTetris(int dy, int dx);
};
#endif